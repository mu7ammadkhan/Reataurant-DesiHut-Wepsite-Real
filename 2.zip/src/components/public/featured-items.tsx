"use client";

import { useEffect, useState } from "react";

type MenuItem = {
  _id: string;
  name: string;
  price: number;
  category?: string;
  isPopular?: boolean;
  image?: string;
};

const fallbackImages = [
  "/placeholders/res1.jpg",
  "/placeholders/res2.jpg",
  "/placeholders/res3.jpg",
];

export default function FeaturedItems() {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/menu")
      .then((res) => res.json())
      .then((data) => {
        setItems(data.data || []);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching menu:", error);
        setLoading(false);
      });
  }, []);

  const displayItems =
    items.length >= 3
      ? items.slice(0, 3)
      : [
          {
            _id: "1",
            name: "Lorem Ipsum",
            price: 45,
            image: fallbackImages[0],
          },
          {
            _id: "2",
            name: "Lorem Ipsum",
            price: 45,
            image: fallbackImages[1],
          },
          {
            _id: "3",
            name: "Lorem Ipsum",
            price: 45,
            image: fallbackImages[2],
          },
        ];

  return (
    <section className="relative overflow-hidden bg-[#f2f2f2] px-4 py-14 sm:px-6 lg:px-8 lg:py-20">
      <div className="mx-auto max-w-[1680px]">
        <div className="relative mb-12 flex flex-col items-center justify-center gap-6 lg:mb-16">
          <h2 className="text-center text-4xl font-extrabold tracking-tight text-black sm:text-5xl lg:text-[58px]">
            Special
          </h2>

          <button className="lg:absolute lg:right-8 lg:top-0 flex items-center gap-4 bg-white px-8 py-5 text-[18px] font-medium text-black shadow-none transition hover:shadow-sm">
            <span className="h-3 w-3 rounded-full bg-red-500" />
            View The Menu
          </button>
        </div>

        <div className="relative">
          <div className="absolute left-0 top-4 hidden lg:block">
            <div className="grid grid-cols-11 gap-x-5 gap-y-5">
              {Array.from({ length: 110 }).map((_, i) => (
                <span key={i} className="h-[6px] w-[6px] rounded-full bg-red-500" />
              ))}
            </div>
          </div>

          <div className="absolute right-0 top-0 hidden xl:block">
            <div className="pr-4 pt-2">
              <div className="mb-10 h-7 w-64 bg-[#ebebeb]" />
              <div className="select-none text-[180px] font-extrabold leading-[0.82] tracking-tight text-[#e8e8e8] [writing-mode:vertical-rl]">
                Special
              </div>
            </div>
          </div>

          {loading ? (
            <div className="py-16 text-center text-gray-500">Loading...</div>
          ) : (
            <div className="relative z-10 grid grid-cols-1 gap-8 md:grid-cols-2 xl:grid-cols-3 xl:gap-10">
              {displayItems.map((item, index) => {
                const isCenter = index === 1;
                const imageSrc =
                  item.image || fallbackImages[index] || "/placeholders/special-1.png";

                return (
                  <div
                    key={item._id}
                    className="mx-auto w-full max-w-[430px]"
                  >
                    <div className="relative min-h-[520px] bg-[#fbfbfb] px-8 pb-10 pt-10 shadow-[0_8px_24px_rgba(0,0,0,0.06)] lg:min-h-[545px]">
                      <div className="flex justify-center">
                        <img
                          src={imageSrc}
                          alt={item.name}
                          className="h-[250px] w-[250px] object-contain sm:h-[280px] sm:w-[280px]"
                        />
                      </div>

                      <div className="mt-10 max-w-[220px] pl-2">
                        <h3
                          className={`text-[26px] font-extrabold leading-[1.25] ${
                            isCenter ? "text-red-500" : "text-black"
                          }`}
                        >
                          {item.name}
                        </h3>
                        <p className="mt-2 text-[26px] font-extrabold leading-[1.25] text-black">
                          Dolor Sit Amet
                        </p>
                      </div>

                      <div
                        className={`absolute bottom-8 right-8 flex h-[92px] w-[92px] items-center justify-center rounded-full text-[22px] font-extrabold text-white ${
                          isCenter ? "bg-red-500" : "bg-[#2f2f34]"
                        }`}
                      >
                        ${item.price}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
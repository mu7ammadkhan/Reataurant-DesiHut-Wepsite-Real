"use client";

import Link from "next/link";
import { FaSearch, FaChevronDown, FaBars, FaTimes } from "react-icons/fa";
import { useState } from "react";

const navItems = [
  { name: "Home", href: "/" },
  { name: "Pages", href: "#", hasDropdown: true },
  { name: "About Us", href: "/about" },
  { name: "Menu", href: "/menu" },
  { name: "Awards", href: "#" },
  { name: "Testimonials", href: "#" },
  { name: "Reservation", href: "/contact" },
  { name: "Contact", href: "/contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <header className="absolute left-0 top-0 z-50 w-full">
        <div className="mx-auto flex max-w-[1600px] items-center justify-between px-5 py-6 sm:px-8 lg:px-10">
          <Link
            href="/"
            className="text-2xl font-extrabold tracking-tight text-white sm:text-3xl"
          >
            Desi Hut
          </Link>

          <nav className="hidden xl:flex items-center gap-8 2xl:gap-10">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center gap-2 text-sm font-semibold transition ${
                  item.name === "Home"
                    ? "text-red-500"
                    : "text-white hover:text-red-400"
                }`}
              >
                {item.name}
                {item.hasDropdown && <FaChevronDown className="text-xs" />}
              </Link>
            ))}
          </nav>

          <div className="hidden xl:flex items-center gap-5 text-white">
            <button
              type="button"
              aria-label="Search"
              className="text-lg transition hover:text-red-400"
            >
              <FaSearch />
            </button>
          </div>

          <button
            type="button"
            aria-label="Toggle menu"
            onClick={() => setOpen(true)}
            className="xl:hidden text-2xl text-white"
          >
            <FaBars />
          </button>
        </div>
      </header>

      {open && (
        <div
          className="fixed inset-0 z-[60] bg-black/60 xl:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      <aside
        className={`fixed right-0 top-0 z-[70] h-full w-[82%] max-w-[360px] bg-black px-6 py-6 text-white shadow-2xl transition-transform duration-300 xl:hidden ${
          open ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <h2 className="text-2xl font-bold">Desi Hut</h2>
          <button
            type="button"
            aria-label="Close menu"
            onClick={() => setOpen(false)}
            className="text-2xl"
          >
            <FaTimes />
          </button>
        </div>

        <nav className="mt-6 flex flex-col">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              onClick={() => setOpen(false)}
              className={`border-b border-white/10 py-4 text-base font-medium transition ${
                item.name === "Home"
                  ? "text-red-500"
                  : "text-white hover:text-red-400"
              }`}
            >
              {item.name}
            </Link>
          ))}
        </nav>
      </aside>
    </>
  );
}
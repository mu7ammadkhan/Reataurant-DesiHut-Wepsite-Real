import { FaUtensils, FaFire, FaClock } from "react-icons/fa";

export default function AboutPreview() {
  return (
    <section className="bg-white px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-10 lg:grid-cols-2">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-red-600">
            About Us
          </p>

          <h2 className="mt-3 text-4xl font-extrabold bg-gradient-to-r from-red-600 to-orange-500 bg-clip-text text-transparent">
            Real Desi Taste, No Compromise
          </h2>

          <p className="mt-4 text-sm leading-7 text-gray-600 sm:text-base">
            At Desi Hut Hyderabad, the focus is simple: proper desi food with
            strong flavor, fresh ingredients, and service that does not waste time.
          </p>

          <div className="mt-7 space-y-4">
            {[
              {
                icon: <FaUtensils className="mt-1 text-lg text-red-600" />,
                title: "Wide Food Variety",
                text: "Biryani, BBQ, burgers, fries, family meals, and more.",
                bg: "from-orange-200/40 to-red-300/30",
              },
              {
                icon: <FaFire className="mt-1 text-lg text-red-600" />,
                title: "Freshly Prepared",
                text: "Hot food, fresh cooking, and proper desi flavor.",
                bg: "from-red-200/40 to-pink-300/30",
              },
              {
                icon: <FaClock className="mt-1 text-lg text-red-600" />,
                title: "Fast Service",
                text: "Built for dine-in, takeaway, and quick customer handling.",
                bg: "from-yellow-200/40 to-orange-300/30",
              },
            ].map((item) => (
              <div
                key={item.title}
                className="group relative rounded-3xl bg-white p-4 shadow-xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl"
              >
                <div className={`absolute inset-0 rounded-3xl bg-gradient-to-br ${item.bg} blur-2xl opacity-40 transition-opacity duration-300 group-hover:opacity-80`} />
                <div className="relative z-10 flex items-start gap-3">
                  {item.icon}
                  <div>
                    <h3 className="font-bold text-gray-900">{item.title}</h3>
                    <p className="mt-1 text-sm text-gray-600">{item.text}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="overflow-hidden rounded-[32px] shadow-[0_20px_50px_rgba(0,0,0,0.2)]">
          <img
            src="/placeholders/main.jpg"
            alt="About Desi Hut food"
            className="h-[320px] w-full object-cover sm:h-[420px] lg:h-[520px]"
          />
        </div>
      </div>
    </section>
  );
}
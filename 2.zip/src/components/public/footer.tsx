export default function Footer() {
  return (
    <footer className="bg-rose-50 px-4 py-16">
      <div className="mx-auto max-w-6xl rounded-[32px] bg-slate-800 px-6 py-12 text-center shadow-[0_20px_50px_rgba(0,0,0,0.25)]">
        <p className="text-lg font-semibold text-white mb-4">
          © 2026 Desi Hut Hyderabad
        </p>

        <div className="mb-4 flex items-center justify-center gap-4">
          <a href="/menu" className="text-orange-300 underline underline-offset-4 hover:text-orange-200">
            Menu
          </a>
          <span className="text-white/40">|</span>
          <a href="/contact" className="text-orange-300 underline underline-offset-4 hover:text-orange-200">
            Contact Us
          </a>
        </div>

        <p className="text-sm text-white/70">
          Fresh food. Fast service. Real desi taste.
        </p>
      </div>
    </footer>
  );
}
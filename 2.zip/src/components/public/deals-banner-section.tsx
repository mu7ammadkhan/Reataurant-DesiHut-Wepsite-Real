export default function DealsSection() {
  const deals = [
    {
      title: "Family Feast Combo",
      subtitle: "Big Deal",
      price: "$45",
      image: "/placeholders/image copy 2.png",
      accent: "dark",
    },
    {
      title: "Lunch Special Combo",
      subtitle: "Hot Offer",
      price: "$25",
      image: "/placeholders/image copy 3.png",
      accent: "red",
    },
    {
      title: "Weekend Sharing Box",
      subtitle: "Chef Pick",
      price: "$35",
      image: "/placeholders/image copy 4.png",
      accent: "dark",
    },
  ];

  return (
    <section className="relative overflow-hidden bg-[#f3f3f3] px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-14 text-center">
          <h2 className="text-4xl font-extrabold text-black sm:text-5xl">
            Family Deals
          </h2>
          <p className="mt-3 text-sm text-gray-500 sm:text-base">
            Best value offers for families and groups
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 xl:grid-cols-3">
          {deals.map((deal, index) => {
            const isRed = deal.accent === "red";

            return (
              <div
                key={index}
                className="group relative mx-auto flex w-full max-w-[430px] justify-center"
              >
                <div className="relative min-h-[540px] w-full bg-white px-6 pb-10 pt-10 shadow-[0_10px_30px_rgba(0,0,0,0.06)] transition duration-300 group-hover:-translate-y-2 group-hover:shadow-[0_18px_40px_rgba(0,0,0,0.10)] sm:px-10">
                  <div className="flex justify-center">
                    <img
                      src={deal.image}
                      alt={deal.title}
                      className="h-[240px] w-[240px] rounded-full object-cover shadow-md sm:h-[280px] sm:w-[280px]"
                    />
                  </div>

                  <div className="mt-8">
                    <p
                      className={`text-sm font-semibold uppercase tracking-[0.2em] ${
                        isRed ? "text-red-500" : "text-gray-400"
                      }`}
                    >
                      {deal.subtitle}
                    </p>

                    <h3
                      className={`mt-4 text-3xl font-extrabold leading-tight ${
                        isRed ? "text-red-500" : "text-black"
                      }`}
                    >
                      {deal.title}
                    </h3>

                    <p className="mt-4 max-w-[260px] text-sm leading-7 text-gray-500">
                      Perfectly packed for sharing, full of flavor, and worth the
                      price.
                    </p>
                  </div>

                  <div
                    className={`absolute bottom-8 right-6 flex h-24 w-24 items-center justify-center rounded-full text-2xl font-extrabold text-white shadow-lg sm:right-8 ${
                      isRed ? "bg-red-500" : "bg-[#2f2f34]"
                    }`}
                  >
                    {deal.price}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
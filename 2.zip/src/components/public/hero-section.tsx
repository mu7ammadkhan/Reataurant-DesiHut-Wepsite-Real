"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  FaArrowRight,
  FaFacebookF,
  FaInstagram,
  FaTwitter,
} from "react-icons/fa";

const slides = [
  {
    id: 1,
    image: "/placeholders/imgsec1.webp",
    title: "Desi Flavor Redefined",
    description:
      "Experience rich taste, fresh ingredients, and premium presentation with every meal at Desi Hut Hyderabad.",
  },
  {
    id: 2,
    image: "/placeholders/imgsec2.jpg",
    title: "Fresh Food. Bold Taste.",
    description:
      "From signature platters to customer favorites, every dish is prepared to actually impress, not just fill space.",
  },
  {
    id: 3,
    image: "/placeholders/imgsec3.jpg",
    title: "A Better Dining Experience",
    description:
      "Food, ambience, and service designed to feel premium while still staying rooted in real desi taste.",
  },
];

export default function HeroSection() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 4000);

    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => {
    setCurrent((prev) => (prev + 1) % slides.length);
  };

  const activeSlide = slides[current];

  return (
    <section className="relative h-screen min-h-[720px] w-full overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={activeSlide.image}
          alt={activeSlide.title}
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-black/35" />
      </div>

      <div className="absolute left-0 top-0 z-10 h-full w-full">
        <div className="relative h-full">
          <div className="absolute left-0 top-0 h-full w-full max-w-[520px] bg-black/45 backdrop-blur-[2px]" />

          <div className="relative z-20 flex h-full w-full items-center">
            <div className="mx-auto flex h-full w-full max-w-[1600px] items-center px-5 sm:px-8 lg:px-10">
              <div className="w-full max-w-[470px] pt-24 sm:pt-28">
                <h1 className="text-4xl font-extrabold leading-none text-white sm:text-5xl lg:text-6xl 2xl:text-7xl">
                  {activeSlide.title}
                </h1>

                <p className="mt-6 max-w-[380px] text-base leading-8 text-white/90 sm:text-lg">
                  {activeSlide.description}
                </p>

                <Link
                  href="/contact"
                  className="mt-10 inline-flex items-center gap-4 bg-white px-8 py-5 text-lg font-semibold text-slate-900 transition hover:bg-red-500 hover:text-white"
                >
                  <span className="inline-block h-3 w-3 rounded-full bg-red-500" />
                  Reservation
                </Link>
              </div>
            </div>
          </div>

          <div className="absolute right-6 top-1/2 z-20 hidden -translate-y-1/2 flex-col items-center gap-7 text-white lg:flex">
            <FaFacebookF className="cursor-pointer text-lg transition hover:text-red-400" />
            <FaInstagram className="cursor-pointer text-lg transition hover:text-red-400" />
            <FaTwitter className="cursor-pointer text-lg transition hover:text-red-400" />
          </div>

          <button
            type="button"
            onClick={nextSlide}
            aria-label="Next slide"
            className="absolute bottom-8 left-1/2 z-20 flex h-16 w-16 -translate-x-1/2 items-center justify-center rounded-full bg-white text-2xl text-slate-900 shadow-2xl transition hover:scale-105 hover:bg-red-500 hover:text-white sm:bottom-10 sm:h-20 sm:w-20"
          >
            <FaArrowRight />
          </button>

          <div className="absolute bottom-8 right-5 z-20 flex items-center gap-2 sm:right-8 lg:right-10">
            {slides.map((slide, index) => (
              <button
                key={slide.id}
                type="button"
                aria-label={`Go to slide ${index + 1}`}
                onClick={() => setCurrent(index)}
                className={`h-1.5 rounded-full transition-all ${
                  current === index ? "w-10 bg-white" : "w-4 bg-white/45"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
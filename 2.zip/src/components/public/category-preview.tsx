import { FaArrowRight } from "react-icons/fa";

const categories = [
  {
    title: "Biryani",
    image: "/placeholders/res2.jpg",
    description: "Rich rice, strong masala, and proper desi taste.",
  },
  {
    title: "BBQ",
    image: "/placeholders/res3.jpg",
    description: "Smoky flavor, grilled perfection, and family sharing.",
  },
  {
    title: "Fast Food",
    image: "/placeholders/res1.jpg",
    description: "Burgers, fries, and quick meals that still hit hard.",
  },
];

export default function CategoryPreview() {
  return (
    <section className="bg-rose-50 px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl text-center">
        <h2 className="text-4xl font-extrabold bg-gradient-to-r from-red-600 to-orange-500 bg-clip-text text-transparent sm:text-5xl">
          Explore Categories
        </h2>
        <p className="mt-3 text-gray-500">Start with what you actually want</p>

        <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((category) => (
            <div
              key={category.title}
              className="group overflow-hidden rounded-3xl bg-white shadow-xl transition-all duration-300 hover:-translate-y-3 hover:shadow-2xl"
            >
              <div className="overflow-hidden">
                <img
                  src={category.image}
                  alt={category.title}
                  className="h-60 w-full object-cover transition duration-300 group-hover:scale-105"
                />
              </div>

              <div className="p-5 text-left">
                <h3 className="text-2xl font-bold text-gray-900">{category.title}</h3>
                <p className="mt-2 text-sm text-gray-600">{category.description}</p>

                <button className="mt-5 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-red-600 to-orange-500 px-4 py-2 text-sm font-bold text-white shadow-md transition hover:shadow-lg">
                  Explore
                  <FaArrowRight />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}